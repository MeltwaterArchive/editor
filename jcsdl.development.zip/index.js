var winSizes = [320, 480, 600, 800, 1000, 1200];
var getWindowSize = function() {
	var winWidth = $(window).width();
	var windowSize = 320;
	$.each(winSizes, function(i, size) {
		if (winWidth >= size) {
			windowSize = size;
		}
	});
	return windowSize;
}

var setWindowSize = function(size) {
	size = ($.inArray(size, winSizes)) ? size : getWindowSize();

	var $bd = $(document.body);
	$.each(winSizes, function(i, winSize) {
		$bd.removeClass('width-' + winSize);
	});

	$bd.addClass('width-' + size);
}

var adjustWindowSize = function() {
	var size = getWindowSize();
	setWindowSize(size);
}


$(function() {

	adjustWindowSize();
	$(window).resize(function(ev) {
		adjustWindowSize();
	});

	// tabs
	$('#tabs li a').click(function(ev) {
		ev.preventDefault();
		ev.target.blur();

		$('#tabs li a').removeClass('active');
		$(this).addClass('active');

		$('#content .tab-content').hide();
		$('#tab-' + $(this).data('tab')).show();
	});

	/*
	 * CREATE STREAM TAB
	 */
	var createEditor = new JCSDLGui('#jcsdl-create', {
		cancelButton : false,
		hideTargets : ['myspace', 'digg.comment', 'facebook.og'],
		definition: {
			operators : {
				exists : {
					description : 'Lorem ipsum dolor sit amet, this is overwritten by local editor definition of JCSDL! Do not worry ;)'
				}
			}
		},
		save : function(code) {
			$('#jcsdl-create-output').val(code);

			// read the title
			var title = $('#stream-title').val();
			if (title.length == 0) {
				alert('Stream title is required!');
				return;
			}

			// insert to the edit stream tab
			var $streamTemplate = $('#streams-list li:first').clone();
			$streamTemplate.find('h4').html(title);
			$streamTemplate.find('.jcsdl-source').val(code);
			$streamTemplate.find('.options .live').remove(); // impossible to see it live
			$streamTemplate.appendTo($('#streams-list'));

			// reset the editor
			$('#stream-title').val('');
			this.reset();
		}
	});
	
	/*
	 * EDIT STREAM TAB
	 */
	var $currentStream = $();

	var editEditor = new JCSDLGui('#jcsdl-edit', {
		save : function(code) {
			// display the output
			$('#jcsdl-edit-output').val(code);

			// and save it as well
			$currentStream.find('.jcsdl-source').val(code);

			// hide the editor and show the list
			$('#streams-list').show();
			$('#jcsdl-edit-wrap').hide();
		},
		cancel : function() {
			this.$container.fadeOut(this.config.animationSpeed, function() {
				$('#streams-list').show();
			});
		}
	});

	$('#streams-list').on('click', '.edit', function(ev) {
		ev.preventDefault();
		ev.target.blur();

		$currentStream = $(this).closest('li');
		var code = $currentStream.find('.jcsdl-source').val();
		editEditor.loadJCSDL(code);

		// clear the output as well
		$('#jcsdl-edit-output').val('');

		// hide the list and show the editor
		$('#streams-list').hide();
		$('#jcsdl-edit-wrap').show();
	});

	$('#streams-list').on('click', '.source', function(ev) {
		ev.preventDefault();
		ev.target.blur();

		var code = $(this).closest('li').find('.jcsdl-source').val();
		$('#jcsdl-edit-output').val(code);
	});

	/*
	 * STYLING SHORTCUT
	 */
	//$('#jcsdl-create .filter-add').click();

});